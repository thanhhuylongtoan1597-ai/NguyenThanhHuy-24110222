import heapq
import time
from collections import deque
import random

def matrix_to_string(matrix):
    return "".join("".join(str(value) for value in row) for row in matrix)

def possible_moves(matrix, x, y):
    moves = []
    if matrix[x][y] == 1:
        moves.append("SUCK")
    if x > 0:   moves.append("UP")
    if x < 2:   moves.append("DOWN")  # Giới hạn lưới 3x3
    if y > 0:   moves.append("LEFT")
    if y < 2:   moves.append("RIGHT") # Giới hạn lưới 3x3
    return moves

def act(matrix, action, x, y):
    matrix_copy = [row[:] for row in matrix]
    i, j = x, y
    if action == "UP":     i -= 1
    elif action == "DOWN":  i += 1
    elif action == "LEFT":  j -= 1
    elif action == "RIGHT": j += 1
    elif action == "SUCK":  matrix_copy[i][j] = 0
    return matrix_copy, i, j


def run_bfs1(start, sx, sy, goal):
    start_time = time.time()
    node = (start, sx, sy, [])
    frontier = deque([node])
    reached = set()
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.popleft()
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        reached.add(state)

        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                in_frontier = False
                for item in frontier:
                    if (matrix_to_string(item[0]), item[1], item[2]) == child_state:
                        in_frontier = True
                        break
                if not in_frontier:
                    frontier.append((new_matrix, nx, ny, path + [action]))

    return None, node_count, (time.time() - start_time) * 1000


def run_bfs2(start, sx, sy, goal):
    start_time = time.time()
    if start == goal:
        return [], 1, (time.time() - start_time) * 1000

    node = (start, sx, sy, [])
    frontier = deque([node])
    reached = set()
    reached.add((matrix_to_string(start), sx, sy))
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.popleft()
        node_count += 1

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                new_path = path + [action]
                if new_matrix == goal:
                    return new_path, node_count, (time.time() - start_time) * 1000
                frontier.append((new_matrix, nx, ny, new_path))
                reached.add(child_state)

    return None, node_count, (time.time() - start_time) * 1000


def run_dfs1(start, sx, sy, goal):
    start_time = time.time()
    node = (start, sx, sy, [])
    frontier = [node]
    reached = set()
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.pop()
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        reached.add(state)

        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                in_frontier = False
                for item in frontier:
                    if (matrix_to_string(item[0]), item[1], item[2]) == child_state:
                        in_frontier = True
                        break
                if not in_frontier:
                    frontier.append((new_matrix, nx, ny, path + [action]))

    return None, node_count, (time.time() - start_time) * 1000


def run_dfs2(start, sx, sy, goal):
    start_time = time.time()
    if start == goal:
        return [], 1, (time.time() - start_time) * 1000

    node = (start, sx, sy, [])
    frontier = [node]
    reached = set()
    reached.add((matrix_to_string(start), sx, sy))
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.pop()
        node_count += 1

        for action in reversed(possible_moves(current_matrix, x, y)):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                new_path = path + [action]
                if new_matrix == goal:
                    return new_path, node_count, (time.time() - start_time) * 1000
                frontier.append((new_matrix, nx, ny, new_path))
                reached.add(child_state)

    return None, node_count, (time.time() - start_time) * 1000

def run_ucs(start, sx, sy, goal):
    start_time = time.time()
    frontier = [(0, start, sx, sy, [])]
    reached = {}
    node_count = 0
    while frontier:
        cost, current_matrix, x, y, path = heapq.heappop(frontier)
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000
        if state not in reached or cost < reached[state]:
            reached[state] = cost
            for action in possible_moves(current_matrix, x, y):
                new_matrix, nx, ny = act(current_matrix, action, x, y)
                heapq.heappush(frontier, (cost + 1, new_matrix, nx, ny, path + [action]))
    return None, node_count, (time.time() - start_time) * 1000

def run_ids_1(start, sx, sy, goal):
    start_time = time.time()
    def dls(matrix, x, y, goal, limit, path):
        if matrix == goal: return path
        if limit <= 0: return None
        for action in possible_moves(matrix, x, y):
            new_m, nx, ny = act(matrix, action, x, y)
            res = dls(new_m, nx, ny, goal, limit - 1, path + [action])
            if res is not None: return res
        return None
    for limit in range(50):
        res = dls(start, sx, sy, goal, limit, [])
        if res is not None:
            return res, limit * 10, (time.time() - start_time) * 1000
    return None, 0, (time.time() - start_time) * 1000

def run_ids_2(start, sx, sy, goal):
    start_time = time.time()
    def dls_with_cycle_check(matrix, x, y, goal, limit, path, visited_in_path):
        state = (matrix_to_string(matrix), x, y)
        if state in visited_in_path:
            return None
        
        if matrix == goal: 
            return path
        if limit <= 0: 
            return None
            
        visited_in_path.add(state)
        
        for action in possible_moves(matrix, x, y):
            new_m, nx, ny = act(matrix, action, x, y)
            res = dls_with_cycle_check(new_m, nx, ny, goal, limit - 1, path + [action], visited_in_path)
            if res is not None: 
                return res
        
        visited_in_path.remove(state) 
        return None

    for limit in range(50):
        res = dls_with_cycle_check(start, sx, sy, goal, limit, [], set())
        if res is not None:
            return res, limit * 15, (time.time() - start_time) * 1000
    return None, 0, (time.time() - start_time) * 1000

def heuristic(matrix):
    return sum(row.count(1) for row in matrix)

def run_greedy(start, sx, sy, goal):
    start_time = time.time()
    h_start = heuristic(start)
    frontier = [(h_start, start, sx, sy, [])]
    reached = set()
    node_count = 0

    while frontier:
        _, current_matrix, x, y, path = heapq.heappop(frontier)
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        
        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000
            
        reached.add(state)

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)
            
            in_frontier = any((matrix_to_string(item[1]), item[2], item[3]) == child_state for item in frontier)

            if child_state not in reached and not in_frontier:
                h_m = heuristic(new_matrix)
                heapq.heappush(frontier, (h_m, new_matrix, nx, ny, path + [action]))
            elif child_state in reached or in_frontier:
                continue

    return None, node_count, (time.time() - start_time) * 1000

def run_astar(start, sx, sy, goal):
    start_time = time.time()
    g_costs = {}
    start_state = (matrix_to_string(start), sx, sy)
    
    g_costs[start_state] = 0
    h_start = heuristic(start)
    
    frontier = [(h_start, start, sx, sy, [])]
    reached = set()
    node_count = 0

    while frontier:
        f_val, current_matrix, x, y, path = heapq.heappop(frontier)
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        curr_g = g_costs[state]

        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        reached.add(state)

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)
            
            g_new = curr_g + 1 if action == "SUCK" else curr_g
            
            in_frontier = any((matrix_to_string(item[1]), item[2], item[3]) == child_state for item in frontier)

            if child_state in reached:
                if g_new >= g_costs.get(child_state, float('inf')):
                    continue
                else:
                    reached.remove(child_state)
                    g_costs[child_state] = g_new
                    h_m = heuristic(new_matrix)
                    heapq.heappush(frontier, (g_new + h_m, new_matrix, nx, ny, path + [action]))
                    
            elif in_frontier:
                if g_new < g_costs.get(child_state, float('inf')):
                    g_costs[child_state] = g_new
                    h_m = heuristic(new_matrix)
                    
                    for i, item in enumerate(frontier):
                        if (matrix_to_string(item[1]), item[2], item[3]) == child_state:
                            frontier[i] = (g_new + h_m, item[1], item[2], item[3], path + [action])
                            break
                    heapq.heapify(frontier)
                    
            elif child_state not in reached and not in_frontier:
                g_costs[child_state] = g_new
                h_m = heuristic(new_matrix)
                f_m = g_new + h_m
                heapq.heappush(frontier, (f_m, new_matrix, nx, ny, path + [action]))

    return None, node_count, (time.time() - start_time) * 1000

def run_idastar(start, sx, sy, goal):
    start_time = time.time()
    node_count = [0]

    def dls_astar(matrix, x, y, goal, g_cost, threshold, path, visited_in_path):
        node_count[0] += 1
        
        h_cost = heuristic(matrix)
        f_cost = g_cost + h_cost
        
        if f_cost > threshold:
            return f_cost, None
            
        if matrix == goal:
            return f_cost, path
            
        state = (matrix_to_string(matrix), x, y)
        if state in visited_in_path:
            return float('inf'), None
            
        visited_in_path.add(state)
        min_cutoff_threshold = float('inf')
        
        for action in possible_moves(matrix, x, y):
            new_m, nx, ny = act(matrix, action, x, y)
            
            g_new = g_cost + 1 if action == "SUCK" else g_cost
            
            res_f, res_path = dls_astar(new_m, nx, ny, goal, g_new, threshold, path + [action], visited_in_path)
            
            if res_path is not None:
                return res_f, res_path
                
            if res_f < min_cutoff_threshold:
                min_cutoff_threshold = res_f
                
        visited_in_path.remove(state)
        return min_cutoff_threshold, None

    threshold = heuristic(start)
    
    while threshold != float('inf'):
        res_f, path = dls_astar(start, sx, sy, goal, 0, threshold, [], set())
        
        if path is not None:
            return path, node_count[0], (time.time() - start_time) * 1000
            
        if res_f == float('inf'):
            break
            
        threshold = res_f
        
    return None, node_count[0], (time.time() - start_time) * 1000

def run_simple_hill_climbing(start, sx, sy, goal):
    start_time = time.time()
    current_matrix = [row[:] for row in start]
    cx, cy = sx, sy
    path = []
    node_count = 0

    while True:
        node_count += 1
        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        curr_val = -heuristic(current_matrix)
        found_next = False

        for action in possible_moves(current_matrix, cx, cy):
            new_matrix, nx, ny = act(current_matrix, action, cx, cy)
            next_val = -heuristic(new_matrix)

            if next_val > curr_val:
                current_matrix, cx, cy = new_matrix, nx, ny
                path.append(action)
                found_next = True
                break

        if not found_next:
            return None, node_count, (time.time() - start_time) * 1000


def run_steepest_hill_climbing(start, sx, sy, goal):
    start_time = time.time()
    current_matrix = [row[:] for row in start]
    cx, cy = sx, sy
    path = []
    node_count = 0

    while True:
        node_count += 1
        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        curr_val = -heuristic(current_matrix)
        best_neighbor = None
        best_val = -float('inf')
        best_action = None
        best_x, best_y = cx, cy

        for action in possible_moves(current_matrix, cx, cy):
            new_matrix, nx, ny = act(current_matrix, action, cx, cy)
            next_val = -heuristic(new_matrix)

            if next_val > best_val:
                best_val = next_val
                best_neighbor = new_matrix
                best_action = action
                best_x, best_y = nx, ny

        if best_neighbor is not None and best_val > curr_val:
            current_matrix = best_neighbor
            cx, cy = best_x, best_y
            path.append(best_action)
        else:
            return None, node_count, (time.time() - start_time) * 1000


def run_stochastic_hill_climbing(start, sx, sy, goal):
    start_time = time.time()
    current_matrix = [row[:] for row in start]
    cx, cy = sx, sy
    path = []
    node_count = 0

    while True:
        node_count += 1
        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        curr_val = -heuristic(current_matrix)
        better_neighbors = []

        for action in possible_moves(current_matrix, cx, cy):
            new_matrix, nx, ny = act(current_matrix, action, cx, cy)
            next_val = -heuristic(new_matrix)

            if next_val > curr_val:
                better_neighbors.append((new_matrix, nx, ny, action))

        if not better_neighbors:
            return None, node_count, (time.time() - start_time) * 1000
        else:
            next_choice = random.choice(better_neighbors)
            current_matrix, cx, cy, chosen_action = next_choice
            path.append(chosen_action)

def run_random_restart_hc(start, sx, sy, goal, max_restart=10):
    start_time = time.time()
    
    for i in range(max_restart):
        current_matrix = [row[:] for row in start]
        cx, cy = sx, sy
        path = []
        
        while True:
            if current_matrix == goal:
                return path, i * 1, (time.time() - start_time) * 1000 # i là số lượt restart
            
            better_neighbors = []
            for action in possible_moves(current_matrix, cx, cy):
                new_m, nx, ny = act(current_matrix, action, cx, cy)
                if heuristic(new_m) < heuristic(current_matrix): # Giả sử h(n) càng nhỏ càng tốt
                    better_neighbors.append((new_m, nx, ny, action))
            
            if not better_neighbors:
                break 
            
            next_m, nx, ny, action = random.choice(better_neighbors)
            current_matrix, cx, cy = next_m, nx, ny
            path.append(action)
            
    return None, max_restart, (time.time() - start_time) * 1000

def run_local_beam_search(start, sx, sy, goal, k=3):
    start_time = time.time()
    current_state_set = [(start, sx, sy, [])] 
    
    while True:
        neighbor_states = []
        for matrix, x, y, path in current_state_set:
            if matrix == goal: return path, len(current_state_set), (time.time() - start_time) * 1000
            
            for action in possible_moves(matrix, x, y):
                new_m, nx, ny = act(matrix, action, x, y)
                if new_m == goal: return path + [action], len(current_state_set), (time.time() - start_time) * 1000
                neighbor_states.append((new_m, nx, ny, path + [action]))
        
        if not neighbor_states: break
        
        neighbor_states.sort(key=lambda item: heuristic(item[0]))
        current_state_set = neighbor_states[:k]
        
    return None, 0, (time.time() - start_time) * 1000