import heapq
import time
from collections import deque

def matrix_to_string(matrix):
    return "".join("".join(str(value) for value in row) for row in matrix)

def possible_moves(matrix, x, y):
    moves = []
    if matrix[x][y] == 1:
        moves.append("SUCK")
    if x > 0:   moves.append("UP")
    if x < 2:   moves.append("DOWN")  # Giới hạn lưới 3x3
    if y > 0:   moves.append("LEFT")
    if y < 2:   moves.append("RIGHT") # Giới hạn lưới 3x3
    return moves

def act(matrix, action, x, y):
    matrix_copy = [row[:] for row in matrix]
    i, j = x, y
    if action == "UP":     i -= 1
    elif action == "DOWN":  i += 1
    elif action == "LEFT":  j -= 1
    elif action == "RIGHT": j += 1
    elif action == "SUCK":  matrix_copy[i][j] = 0
    return matrix_copy, i, j


def run_bfs1(start, sx, sy, goal):
    start_time = time.time()
    node = (start, sx, sy, [])
    frontier = deque([node])
    reached = set()
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.popleft()
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        reached.add(state)

        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                in_frontier = False
                for item in frontier:
                    if (matrix_to_string(item[0]), item[1], item[2]) == child_state:
                        in_frontier = True
                        break
                if not in_frontier:
                    frontier.append((new_matrix, nx, ny, path + [action]))

    return None, node_count, (time.time() - start_time) * 1000


def run_bfs2(start, sx, sy, goal):
    start_time = time.time()
    if start == goal:
        return [], 1, (time.time() - start_time) * 1000

    node = (start, sx, sy, [])
    frontier = deque([node])
    reached = set()
    reached.add((matrix_to_string(start), sx, sy))
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.popleft()
        node_count += 1

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                new_path = path + [action]
                if new_matrix == goal:
                    return new_path, node_count, (time.time() - start_time) * 1000
                frontier.append((new_matrix, nx, ny, new_path))
                reached.add(child_state)

    return None, node_count, (time.time() - start_time) * 1000


def run_dfs1(start, sx, sy, goal):
    start_time = time.time()
    node = (start, sx, sy, [])
    frontier = [node]
    reached = set()
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.pop()
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        reached.add(state)

        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                in_frontier = False
                for item in frontier:
                    if (matrix_to_string(item[0]), item[1], item[2]) == child_state:
                        in_frontier = True
                        break
                if not in_frontier:
                    frontier.append((new_matrix, nx, ny, path + [action]))

    return None, node_count, (time.time() - start_time) * 1000


def run_dfs2(start, sx, sy, goal):
    start_time = time.time()
    if start == goal:
        return [], 1, (time.time() - start_time) * 1000

    node = (start, sx, sy, [])
    frontier = [node]
    reached = set()
    reached.add((matrix_to_string(start), sx, sy))
    node_count = 0

    while frontier:
        current_matrix, x, y, path = frontier.pop()
        node_count += 1

        for action in reversed(possible_moves(current_matrix, x, y)):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)

            if child_state not in reached:
                new_path = path + [action]
                if new_matrix == goal:
                    return new_path, node_count, (time.time() - start_time) * 1000
                frontier.append((new_matrix, nx, ny, new_path))
                reached.add(child_state)

    return None, node_count, (time.time() - start_time) * 1000

def run_ucs(start, sx, sy, goal):
    start_time = time.time()
    frontier = [(0, start, sx, sy, [])]
    reached = {}
    node_count = 0
    while frontier:
        cost, current_matrix, x, y, path = heapq.heappop(frontier)
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000
        if state not in reached or cost < reached[state]:
            reached[state] = cost
            for action in possible_moves(current_matrix, x, y):
                new_matrix, nx, ny = act(current_matrix, action, x, y)
                heapq.heappush(frontier, (cost + 1, new_matrix, nx, ny, path + [action]))
    return None, node_count, (time.time() - start_time) * 1000

def run_ids_1(start, sx, sy, goal):
    start_time = time.time()
    def dls(matrix, x, y, goal, limit, path):
        if matrix == goal: return path
        if limit <= 0: return None
        for action in possible_moves(matrix, x, y):
            new_m, nx, ny = act(matrix, action, x, y)
            res = dls(new_m, nx, ny, goal, limit - 1, path + [action])
            if res is not None: return res
        return None
    for limit in range(50):
        res = dls(start, sx, sy, goal, limit, [])
        if res is not None:
            return res, limit * 10, (time.time() - start_time) * 1000
    return None, 0, (time.time() - start_time) * 1000

def run_ids_2(start, sx, sy, goal):
    start_time = time.time()
    def dls_with_cycle_check(matrix, x, y, goal, limit, path, visited_in_path):
        state = (matrix_to_string(matrix), x, y)
        if state in visited_in_path:
            return None
        
        if matrix == goal: 
            return path
        if limit <= 0: 
            return None
            
        visited_in_path.add(state)
        
        for action in possible_moves(matrix, x, y):
            new_m, nx, ny = act(matrix, action, x, y)
            res = dls_with_cycle_check(new_m, nx, ny, goal, limit - 1, path + [action], visited_in_path)
            if res is not None: 
                return res
        
        visited_in_path.remove(state) 
        return None

    for limit in range(50):
        res = dls_with_cycle_check(start, sx, sy, goal, limit, [], set())
        if res is not None:
            return res, limit * 15, (time.time() - start_time) * 1000
    return None, 0, (time.time() - start_time) * 1000

def heuristic(matrix):
    return sum(row.count(1) for row in matrix)

def run_greedy(start, sx, sy, goal):
    start_time = time.time()
    h_start = heuristic(start)
    frontier = [(h_start, start, sx, sy, [])]
    reached = set()
    node_count = 0

    while frontier:
        _, current_matrix, x, y, path = heapq.heappop(frontier)
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        
        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000
            
        reached.add(state)

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)
            in_frontier = any((matrix_to_string(item[1]), item[2], item[3]) == child_state for item in frontier)

            if child_state not in reached and not in_frontier:
                h_m = heuristic(new_matrix)
                heapq.heappush(frontier, (h_m, new_matrix, nx, ny, path + [action]))
            else:
                continue

    return None, node_count, (time.time() - start_time) * 1000

def run_astar(start, sx, sy, goal):
    start_time = time.time()
    g_costs = {}
    start_state = (matrix_to_string(start), sx, sy)
    g_costs[start_state] = 0
    h_start = heuristic(start)
    frontier = [(h_start, start, sx, sy, [])]
    reached = set()
    node_count = 0

    while frontier:
        f_val, current_matrix, x, y, path = heapq.heappop(frontier)
        node_count += 1
        state = (matrix_to_string(current_matrix), x, y)
        curr_g = g_costs.get(state, 0)

        if current_matrix == goal:
            return path, node_count, (time.time() - start_time) * 1000

        reached.add(state)

        for action in possible_moves(current_matrix, x, y):
            new_matrix, nx, ny = act(current_matrix, action, x, y)
            child_state = (matrix_to_string(new_matrix), nx, ny)
            g_new = curr_g + 1 
            in_frontier = any((matrix_to_string(item[1]), item[2], item[3]) == child_state for item in frontier)

            if child_state in reached:
                if g_new >= g_costs.get(child_state, float('inf')):
                    continue
                else:
                    reached.remove(child_state)
                    g_costs[child_state] = g_new
            elif in_frontier:
                if g_new < g_costs.get(child_state, float('inf')):
                    g_costs[child_state] = g_new
                    h_m = heuristic(new_matrix)
                    heapq.heappush(frontier, (g_new + h_m, new_matrix, nx, ny, path + [action]))
                continue
            elif child_state not in reached and not in_frontier:
                g_costs[child_state] = g_new
                h_m = heuristic(new_matrix)
                f_m = g_new + h_m
                heapq.heappush(frontier, (f_m, new_matrix, nx, ny, path + [action]))

    return None, node_count, (time.time() - start_time) * 1000